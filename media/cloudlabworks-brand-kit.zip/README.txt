Cloud Lab Works brand icon — the orca badge (pale teal field, teal rim).

cloudlabworks-icon-<n>.png  transparent round badge, n x n (use anywhere a logo with transparency works)
cloudlabworks-ios-<n>.png   square, white field, badge inset — iPhone/iPad home-screen icon and App Store style (iOS rounds the corners)
cloudlabworks-avatar-1024.png  square, pale field to the edges — for profile pictures that get cropped to a circle (LinkedIn, GitHub, X, Bluesky, Discord)
cloudlabworks.ico           favicon, 16–256 px
cloudlabworks-icon.svg      the vector master

(c) Alex Alvord, Cloud Lab Works. cloudlabworks.dev
